import { defineConfig } from "vite";
import tailwindcss from "@tailwindcss/vite";
import path from "path";
import react from "@vitejs/plugin-react";
import { viteStaticCopy } from "vite-plugin-static-copy";

export default defineConfig(({ mode }) => {
  const isFirefox = mode === "firefox";
  const browser = isFirefox ? "firefox" : "chrome";

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const input: any = {
    main: path.resolve(import.meta.dirname, "index.html"),
    options: path.resolve(import.meta.dirname, "options.html"),
  };

  if (!isFirefox) {
    input.background = path.resolve(import.meta.dirname, "src/lib/background.ts");
  }

  return {
    plugins: [
      react(),
      tailwindcss(),
      viteStaticCopy({
        targets: [
          {
            src: "manifest.json",
            dest: ".",
            rename: { stripBase: true },
          },
        ],
      }),
    ],
    resolve: {
      alias: {
        "@": path.resolve(import.meta.dirname, "./src"),
      },
    },
    build: {
      emptyOutDir: process.env.WATCH ? false : true,
      outDir: `dist/${browser}`,
      rollupOptions: {
        input,
        output: {
          entryFileNames: (chunkInfo) => {
            return chunkInfo.name === "background" ? "[name].js" : "assets/[name].js";
          },
          chunkFileNames: `assets/[name].js`,
          assetFileNames: `assets/[name].[ext]`,
        },
      },
    },
  };
});
